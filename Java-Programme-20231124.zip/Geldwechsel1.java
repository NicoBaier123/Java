/**
  *
  * Description
  * Berechnung des Umtauschwertes eines Dollarbetrags in Euro
  * nach Eingabe des Kurse zB 1,2988 Dollar/Euro 
  * ergibt bei 100 Dollar einen Umtauschwert von 76,99 Euro 
  * @version 1.0 from 02.12.2012
  * @author Bernhard Six
  */

import java.util.Scanner;
public class Geldwechsel1 {
  
  public static double xchange(double amount, double rate) {
    return amount/rate;
  }
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);  
    double dollar, euro, exchangeRate;
    System.out.println("Berechnung des Umtauschwertes\n\n");
    System.out.println();
    System.out.print("Aktueller Dollarkurs pro Euro: ");
    exchangeRate = scanner.nextDouble();
    System.out.print("Dollarbetrag: ");
    dollar = scanner.nextDouble();
    //processing
    euro=xchange(dollar, exchangeRate);
    //output
    System.out.printf("Der Umtauschwert von "+ dollar +" Dollar ist %.2f Euro.\n", euro);
    scanner.close();
  } // end of main
  
} // end of class Geldwechsel
