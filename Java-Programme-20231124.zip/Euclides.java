/**
  *
  * Description
  *
  * @version 1.0 from 09.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;
public class Euclides {
  
  static int ggtRek( int x, int y) {
    if (x==0) return y;
    else 
    if (y==0) return x;
    else 
    if (x<0) return ggtRek(-x,y);
    else 
    if (y<0) return ggtRek(x,-y);
    else
    if (x>y) return ggtRek(y,x);
    else
    return ggtRek(x, y%x);
  }
    
  static int ggt(int x, int y) {
    int rest;
    if (x==0) return y;
    if (y==0) return x;
    if (x<0) x=-x;  // nur pos. Zahlen erlaubt
    if (y<0) y=-y;
    rest= x%y;
    while (rest>0) { 
      x=y;
      y=rest;
      rest=x%y;
    } // end of while
    return y;
  }  
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    int a,b;
    System.out.print("Erste Zahl: ");
    a = scanner.nextInt();
    System.out.print("Zweite Zahl: ");
    b = scanner.nextInt();
    System.out.printf("Der ggT von %d und %d ist %d.\n", a,b, ggtRek(a,b));
  } // end of main
  
} // end of class Euclides
