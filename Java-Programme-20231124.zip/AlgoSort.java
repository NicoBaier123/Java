/**
  *
  * Description
  *
  * @version 1.0 from 15.12.2012
  * @author Bernhard Six
  */

public class AlgoSort {
  
  static void insertionSort(int[] array){
    int j,m;
    for (int i=1; i<array.length ; i++) {
      j=i;
      m=array[i]; // Markerfeld
      while (j>0 && array[j-1] > m) {  // alle Elemente links vom Marker
        // verschiebe ale gr��eren Elemente nach hinten
        array[j]=array[j-1];
        j--;
      } // end of while
      array[j]=m;
    } // end of for 
  } 
  
  static void swap(int[] array, int idx1, int idx2){
    int tmp =array[idx1];
    array[idx1]=array[idx2];
    array[idx2]=tmp;
  }
  
  static void selectionSort(int[] array){
    int marker = array.length-1;
    while (marker >= 0) {
      // Bestimme gr��tes Element 
      int max = 0;
      for (int i=1; i<=marker; i++ ) {
        if (array[i] > array[max]) max=i;
        // tausche array[marker] mit diesem Element
        swap(array, marker, max);
      }  // end of for 
      marker--;  
    } // end of while
  }
  
  static void bubbleSort(int[] array){
    boolean swapped;
    do { 
      swapped=false;
      for (int i=0;i < array.length -1 ; i++ ) {
        if (array[i] > array[i+1]) {
          //  Elemente vertauschen
          swap(array, i, i+1);
          swapped=true;
        } // end of if
      } // end of for
    } while (swapped ); // solange Vertauschung auftritt
  }
  
  static void msort(int[] array, int left, int right ) {
    int i,j, k;
    int[] b = new int[array.length];  
    if (right > left) {
      // zu sortierendes Feld teilen
      int mid = (right + left)/2;
      // Teilfelder sortieren
      msort(array, left, mid);
      msort(array, mid+1, right);
      // Hilfsfeld aufbauen
      for (k=left;k<=mid ;k++ ) b[k]=array[k];
      for (k=mid; k<right; k++) b[right + mid -k]= array[k+1];
      // Ergebnisse mischen �ber Hilfsfeld b
      i=left; j=right;
      for (k=left;k<=right;k++ ) {
        if ( b[i] < b[j]) array[k]=b[i++];
        else array[k]= b[j--];
      } // end of for 
    } // end of if
  }
  
  static void mergeSort(int[] array) {
    msort(array,0,array.length-1);
  }
  
  // Hilfsmethode zum Zerlegen der Folge
  static int partition(int[] array, int u, int o, int p) {
    int pn = u;
    int pv = array[p];
    // pivot-Element an das Ende verschieben
    swap(array,p,o);
    for (int i=u;i<o;i++ ) 
    if (array[i]<=pv) swap(array, pn++, i);
    // Pivot-Element an die richtige Position kopieren  
    swap(array, o, pn);
    // neue Pivot-Position zur�ckgeben
    return pn; 
  }
  
  static void qsort(int[] array, int u, int o) {
    // Pivot-Element bestimmen
    int p=(u+o)/2;
    if (o>u) {
      // Feld zerlegen
      int pn=partition(array, u,o,p);
      // und Partitionen sortieren
      qsort(array, u, pn-1);
      qsort(array, pn+1, o);
    } // end of if
  }
  
  static void quickSort(int[] array) {
    qsort(array, 0, array.length-1);
  }
  
  static void output(int[] array){          ;
    for (int i: array) System.out.printf("%3d", i);
    System.out.println();
    return;
  }
  
  public static void main(String[] args) {
    int[] f= {5,1,8,3,9,2};
    output(f);
    System.out.println("\nSortiert: \n");
    java.util.Arrays.sort(f); output(f);
    
    /*
    quickSort(f); output(f);
    */
  } // end of main
  
} // end of class AlgoSort