/**
  *
  * Description
  * Demonstartion einiger Array-Befehle
  * @version 1.0 from 17.12.2012
  * @author Bernhard Six
  */
import java.util.Arrays;
public class ArrayDemo {
  
  public static void main(String[] args) {
    int[] feld = {6,5,7,10,9,19,8} ;
    int[] array = feld; // Referenz auf den selben Speicherbereich
    //Ausgabe eines Array
    System.out.println(Arrays.toString(feld));
    array[2]=17;
    System.out.println(Arrays.toString(feld));
    //Kopieren
    array=Arrays.copyOf(feld,feld.length);
    array[1]=15;
    System.out.println(Arrays.toString(feld));
    System.out.println(Arrays.toString(array));
    //Sortieren
    Arrays.sort(feld);
    System.out.println("sortiertes Feld:" );
    System.out.println(Arrays.toString(feld));
    // Bin�res Suchen auf sortierten Feldern
    System.out.println("Die 10 befindet sich an Position "+ Arrays.binarySearch(feld, 10)); 
    int pos=Arrays.binarySearch(feld, 11);
    // Element in Array einf�gen an Position pos  
    pos =-pos-1;
    System.out.println("Das Element 11 soll eingef�gt werden an Position "+ pos); 
    int[] feldneu = new int[feld.length+1];
    System.arraycopy(feld,0,feldneu,0,pos);
    feldneu[pos]=11;
    System.out.println(Arrays.toString(feldneu));
    System.arraycopy(feld,pos,feldneu,pos+1,feld.length-pos); 
    System.out.println(Arrays.toString(feldneu));
  } // end of main
  
} // end of class ArrayDemo