/**
  *
  * Description
  *
  * @version 1.0 from 09.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;


public class HexKonverter {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Zahl zwischen 0 und 15: ");
    byte zahl = scanner.nextByte();
    if ((zahl >= 0) && (zahl < 16)) {
      System.out.println((char) ((zahl < 10)
                     ? ('0' + zahl) : ('A' - 10 + zahl)));
    } // end of if
  } // end of main
} // end of class HexKonverter
