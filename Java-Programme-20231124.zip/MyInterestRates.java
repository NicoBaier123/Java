import java.util.Scanner;

public class MyInterestRates {
  
  public static void main( String[] args ) {
    String name;
    double capital, interestRate, interestRates;
    
    System.out.println( "Moin! Wie hei�t denn du?" );
    name = new Scanner( System.in ).nextLine();
    
    System.out.println( "Kapital?" );
    capital = new Scanner( System.in ).nextDouble();
    
    System.out.println( "Zinssatz in Prozent?" );
    interestRate = new Scanner( System.in ).nextDouble();
    
    interestRates = capital * interestRate /100;
    System.out.printf( "%s, deine Zinsen sind  %g%n", name, interestRates );
  }
}
