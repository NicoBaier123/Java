/**
  *
  * Description
  *
  * @version 1.0 from 11.02.2014
  * @author Bernhard Six
  */

public class BucketSort {
  
  public static void bucketsort(char[] array){
    int bucket[]= new int[256];
  
    for (int b: bucket) b=0; // mit 0 initialisieren
    
    /* 
    Die Buchstaben des Char-Feldes kommen in den entsprechenden Bucket 
    array[0] = 'd', bucket['d'] wird um eins erh�ht  ;
    Da der Ascii Wert von 'd'=100, wird bucket[100] um 1 erh�ht.
    array[1] =  'a', bucket ['a'] wird um eins erh�ht, ;
    Da der Ascii-Wert von 'a'= 97, wird bucket[97] um 1 erh�ht;  
    */ 
        
    for (int i=0;i<array.length;i++ ) bucket[array[i]]++;
    
    int k=0;
    for (int i=0;i<256 ;i++ ) {
      // bucket[i] gibt Anzahl der Elemente im bucket[i] an, 
      // z.B. i = 100, d.h. im bucket['d'] an:
      for (int j=0; j< bucket[i];j++ ) { 
        array[k]=(char) i; // 100 in 'd' verwandeln
        k++; 
      } // end of for
    } // end of for i
  }
  
  public static void main(String[] args) {
    String s="dampflokomotivenfuehrerschein";
    /* statt ausf�hrlich:
    char[] f= new char[s.length()];
    for (int i=0;i<s.length() ;i++ ) f[i]=s.charAt(i);
    */
    char[] feld= s.toCharArray(); 
    System.out.println("Anzahl der Buchstaben: "+ feld.length);
    for (char c: feld) System.out.printf("%2s", c);
    System.out.println("\n\nSortiert: \n");
    bucketsort(feld); 
    for (char c: feld) System.out.printf("%2s", c);
  } // end of main
  
} // end of class BucketSort