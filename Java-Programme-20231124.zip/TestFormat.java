/**
  *
  * Description
  *
  * @version 1.0 from 02.12.2012
  * @author Bernhard Six
  */

import java.util.Scanner;
public class TestFormat {
  
  public static void main(String[] args) { 
    double a, b;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Nachkommastellen\n");
    a = 56E-3;    // 56 * 10 hoch minus 3
    b = Math.PI; // 3.1415... 
    System.out.printf("Die erste Zahl ist %.3f.\n", a); //3 Nachkommastellen
    System.out.printf("Die zweite Zahl ist %.4f bzw. %.6f.\n", b,b); //4 bzw. 6 Nachkommastellen
    scanner.close();
  } // end of main
  
} // end of class TestFormat
