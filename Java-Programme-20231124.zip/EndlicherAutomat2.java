public class EndlicherAutomat2 {
  
  public static boolean accepted(String s){
    int[][] delta = { {0,1},
                      {2,0},
                      {1,2}
                    };     
    int cipher=0;  // Um die char des Strings s in Ziffern zu verwandeln
    int status=0;  // Anfangszustand
    for (int i=0; i<s.length(); i++ ) {
      if (s.charAt(i)=='1') cipher=1; else cipher=0; 
      status=delta[status][cipher]; // Transformation zu neuem Zustand
    } // end of for
    return status==0;               // Pr�fung ob Endzustand in F liegt
  }  
  
  public static void main (String [] argv) {    
    String eingabe="101110111011";
    System.out.println(eingabe);
    if (accepted(eingabe)) 
      System.out.println("Die Zahl ist durch drei teilbar."); 
      else System.out.println("Die Zahl ist nicht durch drei teilbar."); 
    int decimalValue = Integer.parseInt(eingabe, 2);
    System.out.println("\nKontrolle: Dezimal hei�t die Zahl " + decimalValue); 
    if (decimalValue%3==0) 
      System.out.println("Sie ist durch drei teilbar."); 
      else System.out.println("Sie ist nicht durch drei teilbar."); 
  }
}