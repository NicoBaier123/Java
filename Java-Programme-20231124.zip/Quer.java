public class Quer {
  
  public static int recQuer (int n) {   
    if (n < 0) return recQuer(-n);    // Sonderfall negative Zahlen      
    if (n==0) return 0;               // Abbruchbedingung          
    return n%10 + recQuer(n/10);      // rek. Aufruf mit verkleinertem Parameter                                   
  }
  
  public static int iterQuer (int n) {  
    if (n<0) n*=-1;        // Sonderfall negative Zahl mit -1 multiplizieren
    int sum=0;             // temp sum             
    while (n>0) { 
      sum+=n%10;           // Einerziffer zu sum addieren 
      n/=10;               // Division durch 10: letzte Ziffer von n entfernen
    } // end of while
    return sum;
  }
  
  public static void main (String [] argv) {    
    System.out.println("Die Quersumme von 1234 ist " + iterQuer(1234));
    System.out.println("Die Quersumme von 1234 ist " + recQuer(1234));
  }
}