/**
  *
  * Description
  *
  * @version 1.0 from 11.01.2013
  * @author Bernhard Six
  */

import java.util.Stack;
import java.util.Scanner;

public class TestStack {
  
  public static void main(String[] args) {
    Stack stack  = new Stack();
    String line;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Gib eine String je Zeile ein. Leere Eingabe beendet die Eingabe.");
    int i=1;
    // so lange Zeilen einlesen und dem Stack hinzuf�gen bis leere Eingabe
    do {
      System.out.printf("\n %3d. Zeile: ", i++);
      line=scanner.nextLine();
      if (!line.isEmpty()) stack.push(line);
    } while (!line.isEmpty() );
    //String s1= (String)stack.pop();
    //System.out.println(s1);
    while (!stack.isEmpty()) {              
      System.out.println(stack.pop());
    } // end of while 
    
  } // end of main
  
} // end of class TestStack
