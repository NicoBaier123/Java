/**
  *
  * Description
  *
  * @version 1.0 from 04.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;

public class Heron {
  public static double heron(double x) {
    double solution,root;
    int i=0;
    root=x;
    do {
      solution=root; 
      i++;
      root=0.5*(x/root+root);
      System.out.printf("%3d. Iteration:  %f\n",i,root);
    } while (root!=solution);
    return root;
  }
  
  public static void main(String[] args) {
    double number,root;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Heron Algorithmus\n");
    do { 
      System.out.print("Positive Zahl: ");
      number=scanner.nextDouble();
    } while (number <0);
    root=heron(number);
    System.out.printf("Die Wurzel von %.3f ist %f\n", number, root);     
  } // end of main
  
} // end of class Heron
