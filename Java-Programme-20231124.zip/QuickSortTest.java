public class QuickSortTest {
  public static void sort (int[] a) {            // �ffentliche Methode
    quicksort(a, 0, a.length-1);                 // startet private Methode
  }
  private static void quicksort (int[] a, int links, int rechts) {
    int swap;                                    // Hilfsvariable
    int i = links;                               // untere Intervallgrenze
    int j = rechts;                              // obere Intervallgrenze
    int mitte = (links + rechts) / 2;            // mittlere Position
    int pv = a[mitte];                           // Pivotelement
    System.out.println("------****----");
    output(a);
    System.out.println("----links: "+links+" rechts: "+rechts+ " pivot: "+pv+"----\n");
    // Partition                                     
    do {
      while (a[i] < pv) i++;                     // pv fungiert als Bremse
      while (a[j] > pv) j--;                     // pv fungiert als Bremse
      if (i <= j) {
        swap = a[i];                             // Hilfsvariable zum Tausch
        a[i] = a[j];                             // a[i] und
        a[j] = swap;                             // a[j] werden getauscht
        i++;
        j--;
        output(a);
      }
    } while (i <= j);
    // Diese Partition garantiert:
    // alle Elemente der linken Array-H�lfte sind kleiner
    // als alle Elemente der rechten Array-H�lfte
    if (links < j) quicksort(a, links, j);       // sortiere linke H�lfte
    if (i < rechts ) quicksort(a, i, rechts);    // sortiere rechte H�lfte
  }
  public static void output(int[] field) {
    for (int i: field) System.out.printf("%3d",i);
    System.out.println();
  }
  
  
  public static void main(String[] args) { 
    int[] intfeld={8,1,6,3,7,5,2,4,9,0}; 
    //int[] intfeld ={0,9,4,2,5,7,3,6,1,8};

    System.out.println("Quicksort");
    
    sort(intfeld);
    
  } // end of main
  
  
}