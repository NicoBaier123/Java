public class EndlicherAutomatA2 {
  /*  
  genau die W�rter aus dem Alphabet {a,b} werden akzeptiert, 
  welche mit a anfangen, darauf einige (auch 0) b folgen 
  und mit a enden. Regex ab*a
  */  
  
  public static boolean contains(char[] charField, char c){
    for (char x: charField) if (x==c) return true;
    return false;
  }
  
  public static boolean contains(int[] intField, int i){
    for (int n: intField) if (n==i) return true;
    return false;
  }  
  
  public static boolean accepted(String s){
    
    char[] alphabet = {'a','b'};  
    int[][] delta = { {1,3}, 
                      {2,1},  
                      {3,3},
                      {3,3}
                    };
  int startstate=0;   
  int[] finalstates={2};
  
  int state=startstate;  // Anfangszustand
  for (int i=0; i<s.length(); i++ ) {
    if (!contains(alphabet,s.charAt(i))) return false;
    // int cipher = s.charAt(i) - 'a'; Umwandlung von a nach 0, b nach 1
    state=delta[state][s.charAt(i) - 'a']; // Transition zu neuem Zustand
  } // end of for
  
  return contains(finalstates,state);// ist erreichter Zustand ein Endzustand?
}  
  
public static void main (String [] argv) {    
  String eingabe="abbba";
  System.out.println(eingabe);
  if (accepted(eingabe)) 
  System.out.println("\nakzeptiert: Anfang und Ende ein a, dazwischen einige b"); 
  else System.out.println("\nnicht akzeptiert"); 
  }
}