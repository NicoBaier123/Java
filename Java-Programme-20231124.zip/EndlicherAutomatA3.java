public class EndlicherAutomatA3 {
  /*  
  genau die W�rter aus dem Alphabet {a,b} werden akzeptiert, 
  welche mit demselben Zeichen beginnen und enden.
  */  
  
  public static boolean contains(char[] charField, char c){
    for (char x: charField) if (x==c) return true;
    return false;
  }
  
  public static boolean contains(int[] intField, int i){
    for (int n: intField) if (n==i) return true;
    return false;
  }  
  
  public static boolean accepted(String s){
    
    char[] alphabet = {'a','b'};  
    int[][] delta = { {1,3}, 
                      {1,2}, 
                      {1,2}, 
                      {4,3},
                      {4,3}
                    };
    int startstate=0;   
    int[] finalstates={1,3};
  
    int state=startstate;  // Anfangszustand
    for (int i=0; i<s.length(); i++ ) {
      if (!contains(alphabet,s.charAt(i))) return false;
      // int cipher = s.charAt(i) - 'a'; Umwandlung von a nach 0, b nach 1
      state=delta[state][s.charAt(i) - 'a']; // Transition zu neuem Zustand
    } // end of for
  
    return contains(finalstates,state);// ist erreichter Zustand ein Endzustand?
  }  
  
  public static void main (String [] argv) {    
    String eingabe="baaabbab";
    System.out.println(eingabe);
    if (accepted(eingabe)) 
      System.out.println("\nakzeptiert: Anfang und Ende gleich"); 
      else System.out.println("\nnicht akzeptiert"); 
  }
}