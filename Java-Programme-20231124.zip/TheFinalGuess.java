/**
  *
  * Description
  *
  * @version 1.0 from 09.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;
 public class TheFinalGuess {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    int number = (int) ((Math.random() * 9) + 1);
    int guess; 
    do {
      System.out.print("Welche Zahl denke ich mir zwischen 1 und 9? ");
      guess = scanner.nextInt();
      if (number == guess) {
        System.out.println("Super getippt!");
      } else if (number > guess) {
        System.out.println("Nee, meine Zahl ist gr��er als deine!");
      } else if (number < guess) {
        System.out.println("Nee, meine Zahl ist kleiner als deine!");
      }
    } while (number != guess);   // end do-while
  } // end of main
} //end of TheFinalGuess
