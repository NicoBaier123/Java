/**
  *
  * Description
  *
  * @version 1.0 from 09.12.2012
  * @author Bernhard Six
  */

public class FinalGuess {
  
  public static void main(String[] args) {
    
  } // end of main

} // end of class FinalGuess
