/**
  *
  * Description
  *
  * @version 1.0 from 05.12.2012
  * @author Bernhard Six
  */

public class HalloString {
  
  public static void main(String[] args) {
    double d=123.456;
    String hallo="Hallo";
    String hello;
    String hallohello;
    System.out.println("hallo: " + hallo);
    hello=hallo.replace('a','e');
    hallohello=hallo+hello;
    System.out.println("hallo: " + hallo);
    System.out.println("hello: " + hello);
    System.out.println("hallohello: " + hallohello);
    System.out.println(d++);
    System.out.println(d);
  }
}