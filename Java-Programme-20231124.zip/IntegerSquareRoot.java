import java.util.Scanner;
public class IntegerSquareRoot {
  
  public static int intsqrt(int n){
    int x,y,z;  
    x = 0; y = 1; z = 1; 
    // x� = n ? z = (x + 1)� ? y = 2x + 1 = Schleifeninvariante P
    while (z <= n)  /* Q */ { 
      x = x + 1; 
      y = y + 2; 
      z = z + y; 
    } 
    return x;    
  }
  
  
  public static int intsqrt_rec(int n) {
     int r, r1;
     if (n==0) return 0;
     else {
       r=intsqrt_rec(n/4);
       if (n<(2*r+1)*(2*r+1)) return 2*r; else return 2*r+1; 
     } // end of if-else
  }
    
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    // input
    int radikand,intsquareroot;
    System.out.println("Berechnung der ganzzahligen Quadratwurzel von n");
    System.out.println(" h�chstens "+Integer.MAX_VALUE);
    do {  
      System.out.print("nicht negativer Radikand : ");
      radikand = scanner.nextInt(); 
    } while (radikand<0 || radikand > Integer.MAX_VALUE);
    intsquareroot= intsqrt_rec(radikand);  
    System.out.println("Die ganzzahlige Wurzel von " + radikand + " ist "+ intsquareroot + ".");
    scanner.close();
  } // end of main
  
} // end of class Zweierpotenz