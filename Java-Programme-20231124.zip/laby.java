/**
  *
  * Description
*                                                                    {
  * @version 1.0 from 12.01.2013
  * @author Bernhard Six
  */
  
  public class laby {
    static char[][] labyrinth = {                               
      {'X','X','X','X',' ','X','X','X','X'},
      {'X',' ','X',' ',' ',' ',' ',' ','X'},
      {'X',' ','X','X',' ','X','X','X','X'},
      {'X',' ',' ',' ',' ',' ',' ',' ','X'},
      {'X',' ','X','X','X','X','X',' ','X'},
      {' ',' ','X',' ',' ',' ',' ',' ','X'},
      {'X','X','X','X','X',' ','X','X','X'}};
    
    static void zeichneLabyrinth(){
      for (int zeile=0;zeile<7 ;zeile++ ) {
        for (int spalte=0;spalte<9 ;spalte++ ) {
          System.out.print(labyrinth[zeile][spalte]);
        } // end of for spalte
        System.out.println();
      } //end of for zeile; 
      
    }    
    
    
    public static void main(String[] args) {
      zeichneLabyrinth();
      
    } // end of main
    
  } // end of class laby
