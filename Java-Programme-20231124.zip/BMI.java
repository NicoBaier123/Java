/**
  *
  * Description
  * Der Body Mass Index berechnet sich nach folgender Formel:
  * K�rpergewicht in Kilogramm geteilt durch   
  * K�rpergr��e in Metern zum Quadrat
  * Beispiel 2 m Groesse un 80 kg ergibt BMI = 20 kg/m2
  *
  * @version 1.0 from 02.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;
public class BMI {
  
  public static void main(String[] args) {
    double weight, height, index;
    Scanner scanner = new Scanner(System.in);
    // input
    System.out.println("Berechnung des Body Mass Index");
    System.out.println();
    System.out.print("K�rpergr��e in Meter: ");
    height = scanner.nextDouble();
    System.out.print("K�rpergewicht in kg: ");
    weight = scanner.nextDouble();
    // processing
    index = weight/(height*height);
    index= Math.round(100*index)/100.0;  //Rundung 2 Nachkommastellen
    //output
    System.out.println("Dein BMI betr�gt " + index + " kg/m2.");
    scanner.close();
  } // end of main
  
} // end of class BMI
