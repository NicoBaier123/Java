  /**
  * Zwei Methoden f und g, deren Korrektheit bewiesen werden soll
  */
import java.util.Scanner;
public class Correctness {
  
  public static int f(int n) {
    // n >= 0 
    int i=0, z=0, j=-1;
    
    while (i<n) {
      i=i+1;
      j=j+2;
      z=z+j;  
    } // end of while
    
    return z;  
  }
  
  public static int g(int n){
    // n >= 0
    if (n==0) return 0;
    else return 2*n - 1 + g(n-1); 
  }
  
  public static int fac(int n) {
    // n>=0  
    int i=0, f=1;
    while (i<n) { 
      i=i+1;
      f=f*i;
    } // end of while
    return f;
  }
  
  public static int facrek(int n){
    // n>=0  
    if (n==0) return 1;
    else return n*facrek(n-1);
  }
  
  
  public static void main(String argv[]) {
    Scanner scanner = new Scanner(System.in);
    int i;
    do {  
      System.out.print("Ganze Zahl gr��er gleich Null: ");
      i= scanner.nextInt(); 
    } while (i < 0);
    
    System.out.printf("\nf(%d) = %d.\n",i,fac(i));
    //System.out.printf("\ng(%d) = %d.\n",i,g(i));
    
    scanner.close();
  }
}