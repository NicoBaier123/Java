/**
  *
  * Description
  * Der Body Mass Index berechnet sich nach folgender Formel:
  * K�rpergewicht in Kilogramm geteilt durch   
  * K�rpergr��e in Metern zum Quadrat
  * Beispiel 2 m Groesse un 80 kg ergibt BMI = 20 kg/m2
  *
  * @version 1.0 from 02.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;

public class BMI_Test {
  
  public static double bodymass(double h, double w) {
     double i= w/(h*h);
     return Math.round(100*i)/100.0;
  }
  
  public static void main(String[] args) {
    double weight, height;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Berechnung des Body Mass Index");
    System.out.println();
    System.out.print("K�rpergr��e in Meter: ");
    height = scanner.nextDouble();
    System.out.print("K�rpergewicht in kg: ");
    weight = scanner.nextDouble();
    System.out.println("Dein BMI betr�gt " + bodymass(height,weight) + " kg/m2.");
  } // end of main
  
} // end of class BMI
