/**
  *
  * Description
  *
  * @version 1.0 from 02.12.2012
  * @author Bernhard Six
  */

public class TestBoolean {
  
  public static void main(String[] args) { 
    Boolean b;
    b = 7<5;
    System.out.println("Das Ergebnis ist " + b); //false bzw. true
  } // end of main
  
} // end of class TestBoolean
