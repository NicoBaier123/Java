/**
  *
  * Description
  *
  * @version 1.0 from 11.01.2013
  * @author Bernhard Six
  */

import java.util.Arrays;
public class RucksackRecursive {
  // Eingabeparameter
  static double capacity = 10.0; 
  static int gesamtzahl=4;
  static double[] weight ={6,2,2,5};
  static double[] value = {5,3,6,4};
  
  static double maxValue=0;
  static double maxWeight=0;
  
  static double max(double a, double b) {
    return (a>b?a:b);
  }
  
  static double rucksack(int i, double currentCapacity){ 
    if (i==gesamtzahl-1)
    if (currentCapacity < weight[i]) return 0; else  return value[i];
    else 
    if (currentCapacity < weight[i]) return rucksack(i+1,currentCapacity);
    else {
      return max (
      rucksack(i+1,currentCapacity),
      rucksack(i+1,currentCapacity-weight[i])+value[i]
      );
    } // end of if-else
    
    
  } // of rucksack
  
  
  
  
  public static void main(String[] args) {
    
    // Ausgabeparameter
    boolean[] solution = {false,false,false,false};
    double maxValue=0;
    double maxWeight=0;
    // Aufruf mit Gegenstand 0 und Gesamtkapazit�t
    
    maxValue=rucksack(0,capacity);
    System.out.println(maxValue);
  } // end of main
  
} // end of class RucksackRecursive
