/**
  *
  * Description
  * Eine eingegebene Sekundenzahl soll im Format
  * Tage - Stunden:Minute:Sekunden dargestellt werden.
  * Beispiel 100000 Sek = 1T 3:46:40 
  * @version 1.0 from 02.12.2012
  * @author Bernhard Six
  */

import java.util.Scanner;
import java.text.DecimalFormat;
public class Zeit2 {
  
  public static String transform(long seconds){
    long days,hours,minutes,sec;
    DecimalFormat df = new DecimalFormat("00"); // 2 Stellen
    String time= new String();
    minutes = seconds / 60;   // Unterteilung in Minuten
    sec=seconds % 60;         // Restsekunden
    hours = minutes / 60;     // Unterteilung in Stunden
    minutes = minutes % 60;   // Restminuten
    days = hours / 24;        // Unterteilung in Tage
    hours = hours % 24;       // Reststunden
    time = days + " Tage " + df.format(hours) + 
    ":"+df.format(minutes)+":"+df.format(sec); 
    return time;
  }
  
  public static void main(String[] args) {
    long seconds; 
    Scanner scanner = new Scanner(System.in);
    // input
    System.out.println("Umwandlung von Sekunden");
    System.out.println();
    System.out.print("Anzahl von Sekunden: ");
    seconds = scanner.nextInt();
    //processing
    // in extra method 
    //output
    System.out.println(seconds + " Sekunden sind " +
                    transform(seconds)+" Stunden.");
  } // end of main
  
} // end of class Zeit