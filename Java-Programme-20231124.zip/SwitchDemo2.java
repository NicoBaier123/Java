/**
  *
  * Description
  *
  * @version 1.0 from 09.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;
public class SwitchDemo2 {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Tageszeit (Morgen, Mittag, Abend, Nacht): "); 
    String zeit = scanner.nextLine().toLowerCase();
    switch (zeit) {
      case "morgen":
        System.out.println("Guten Morgen");
        break;
      case "mittag":
        System.out.println("Guten Tag");
        break;
      case "abend":
        System.out.println("Guten Abend");
        break;
      case "nacht":
        System.out.println("Guten Nacht");
        break;
      default:
        System.out.println("Hallo");
    } //end of switch 
  } // end of main
} // end of class SwitchDemo2                                          
