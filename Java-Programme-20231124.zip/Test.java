/**
  *
  * Description
  *
  * @version 1.0 from 03.12.2012
  * @author Bernhard Six
  */

public class Test {
  
  public static void main(String[] args) {
    
  } // end of main

} // end of class Test
