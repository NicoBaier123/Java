public class Fibo{
  final static double sqrt5= Math.sqrt(5.0);
  final static double phi=(1.0+sqrt5)/2.0; 
  final static double psi = 1-phi;      // dasselbe wie (1-sqrt5)/2
  
  // phi und psi sind die beiden L�sungen der Gleichung
  // x� -x -1 = 0 
  
  public static int fibrek(int n) {
    if ((n==1)||(n==2))  return 1;
    else return fibrek(n-2)+fibrek(n-1);
  }
  
  public static int fibdir(int n){
    double x1,x2,x;
    x1=Math.exp(Math.log(phi)*n); // phi hoch n
    x2=Math.exp(Math.log(-psi)*n); // -psi hoch n
    if (n%2!=0) x2*=-1;         // bei ungeradem n Minus erg�nzen
    x=(x1-x2)/sqrt5;
    return (int)(x+0.5);   // sonst w�rde fib(10) =54.9999999 zu 54 abgerundet
  }
  
  public static int fibiter(int n) {
    int vorvor=1,vor=1, fib=1;
    if ((n==1)||(n==2))  return 1;
    for (int i=3;i<=n ;i++ ) {
      fib=vorvor+vor;
      vorvor=vor;
      vor=fib;
    } // end of for 
    return fib;
  }
  
  public static int fibdyn(int n, int[] t){
    if (t[n]==0) t[n]= fibdyn(n-1,t)+fibdyn(n-2,t);
    return t[n];
  }  
  
  public static int fibdp(int n) {
    int[] tbl = new int[n+2];
    for (int entry: tbl) entry=0; // alle Tabelleneintr�ge auf 0 setzen
    tbl[1]=1; tbl[2]=1;
    return fibdyn(n,tbl);
  }  
  
  public static void main(String[]args) {
    System.out.println("Fibonacci - Sequence\n\n");
    System.out.printf("%2s %5s %5s %5s %5s\n", "Nr", "rek", "direkt", "iter", "dyn" );
    for (int i=1;i<20;i++ ) 
    System.out.printf("%2d %5d %5d %5d %5d\n", i,fibrek(i), fibdir(i), fibiter(i), fibdp(i));  
    System.out.println();
    // Zeitmessung
    long f46, before, after;
    before = System.nanoTime();
    f46 = fibiter(46);   // ca 1 Mikrosek
    after = System.nanoTime();
    System.out.println("Die iterative Berechnung der 46. Fib-Zahl "+ f46+ 
    " dauerte "+(after-before)/1000+" Mikrosek");
    before = System.nanoTime();
    f46 = fibdir(46);   // ca 2 Mikrosek
    after = System.nanoTime();
    System.out.println("Die direkte Berechnung der 46. Fib-Zahl "+ f46+ 
    " dauerte "+(after-before)/1000+" Mikrosek");    
    before = System.nanoTime();
    f46 = fibdp(46);   // ca 5 Mikrosek
    after = System.nanoTime();
    System.out.println("Die dyn. progr. Berechnung der 46. Fib-Zahl "+ f46+ 
    " dauerte "+(after-before)/1000+" Mikrosek");
    before = System.nanoTime();
    f46 = fibrek(46);   // ca 7 Sek
    after = System.nanoTime();
    System.out.println("Die rekursive Berechnung der 46. Fib-Zahl "+ f46+ 
    " dauerte "+(after-before)/1000+" Mikrosek");    
  }
  
  
  
  
}  
