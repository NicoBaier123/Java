************************* StudentComparable***********************************/

public class StudentComparable extends Student implements Comparable { 
  
  /*** Konstruktor mit denselben Parametern wie bei der Klasse Student:
  (String vn,                     // Vorname
  String nn,                     // Nachname 
  int t,                         // Geburtstag
  int m,                         // Geburtsmonat
  int j,                         // Geburtsjahr
  String f,                      // Studienfach 
  int jsb)                       // Studienbeginn 
  */
  
  public StudentComparable(String vn, String nn, int t, int m, int j, String f, int jsb){
    // Aufruf des Konstruktors der Oberklasse
    super(vn,nn, t,m,j,f,jsb);     
  }  
  
  // einzige neue Methode compareTo
  public int compareTo(Object x) {
    if (!(x instanceof StudentComparable)) throw new RuntimeException("Kein StudentComparable"); 
    return this.mat_nr - (StudentComparable) x.mat_nr; // Differenz
    // x ist allgemeines Object, muss daher erst gecastet werden, 
    // damit auf die Matrikelnummer zugegriffen werden kann
  }  
 
} // end of class StudentComparable