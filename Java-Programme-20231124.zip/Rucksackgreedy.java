/**
  *
  * Description
  *
  * @version 1.0 from 11.01.2013
  * @author Bernhard Six
  */

import java.util.Arrays;
public class Rucksackgreedy {
  
  static int[] order(double[] array){
    double[] seq =Arrays.copyOf(array,array.length);
    int[] ordered = new int[array.length];
    int max;
    for (int i=0;i<array.length ;i++ ) {
      max=0;
      for (int j=0;j<array.length ;j++ ) {
        if (seq[j]>seq[max]) {
          max=j;    
        } // end of if    
      } // end of for j
      seq[max]=Double.MIN_VALUE;
      ordered[i]=max;
    } //end of i
    return ordered;
  }
  
  public static void main(String[] args) {
    // Eingabe
    double capacity = 10.0; 
    double[] weight ={6,2,2,5};
    double[] value = {5,3,6,4};
    // Ausgabe
    boolean[] solution = {false,false,false,false};
    double maxValue=0;
    double maxWeight=0;
    
    // Greedy bez�glich Dichte: Wert/Gewicht
    double[] density = new double[4];
    for (int i=0;i<4 ;i++ ) density[i]= Math.round(100*value[i]/weight[i])/100.0;  
    // Ordnen nach Dichte
    int[] reihenfolge = order(density);
    
    System.out.println("Gewicht:     "+ Arrays.toString(weight));
    System.out.println("Wert:        "+ Arrays.toString(value));
    System.out.println("Dichte:      "+ Arrays.toString(density));
    System.out.println("Reihenfolge: "+ Arrays.toString(reihenfolge));
    System.out.println("\nL�sung bei Kapazit�t von "+capacity+" kg:");
    
    for (int i=0; i<4 ;i++ ) {
      if (capacity-weight[reihenfolge[i]]>=0) {
        maxWeight += weight[reihenfolge[i]];
        maxValue  += value[reihenfolge[i]];
        capacity  -= weight[reihenfolge[i]];
        solution[reihenfolge[i]]=true;
      } // end of if
    } // end of for
    
    System.out.println(Arrays.toString(solution)+ " Maximalgewicht "+maxWeight+ " Maximalwert "+ maxValue);                                                                                                         
  } // end of main
  
} // end of class rucksackgreedy
