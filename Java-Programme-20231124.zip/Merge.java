/**
  *
  * Description
  * mergeSort Zeitmessung
  * und Messung der Anzahl der Vergleiche
  * @version 1.0 from 17.12.2012
  * @author Bernhard Six
  */

public class Merge {
  static long counter=0;
  
  static void msort(int[] array, int left, int right ) {
    int i,j, k;
    int[] b = new int[array.length];  
    if (right > left) {
      // zu sortierendes Feld teilen
      int mid = (right + left)/2;
      // Teilfelder sortieren
      msort(array, left, mid);
      msort(array, mid+1, right);
      // Hilfsfeld aufbauen
      for (k=left;k<=mid ;k++ ) b[k]=array[k];
      for (k=mid; k<right; k++) b[right + mid -k]= array[k+1];
      // Ergebnisse mischen �ber Hilfsfeld b
      i=left; j=right;
      for (k=left;k<=right;k++ ) {
        counter++;                 // Vergleichscounter erh�hen
        if ( b[i] < b[j]) array[k]=b[i++];
        else array[k]= b[j--];
      } // end of for 
    } // end of if
  }
  
  static void mergeSort(int[] array) {
    msort(array,0,array.length-1);
  }
  
  static void output(int[] array){          ;
    for(int i=0;i<array.length; i++)System.out.printf("%5d", array[i]);
    System.out.println();
    return;
  }
  
  public static void main(String[] args) {
    int[] f= new int[1000];
    for (int i=0;i<f.length ;i++ ) {
      f[i]=(int)(Math.random()*9999)+1;
    } // end of for
    output(f);
    System.out.println("\nSortiert: \n");
    long before = System.nanoTime();
    //java.util.Arrays.sort(f); 
    mergeSort(f);
    long after =System.nanoTime();
    output(f);
    System.out.printf("\n\n %.2f Millisekunden.\n",(after-before)/1e6);
    System.out.printf("Vergleichz�hler %d\n", counter);
    //; output(f);
  } // end of main
  
} // end of class Merge
