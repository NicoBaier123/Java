public class RucksackTest {
  
  // Daten Saake/Sattler S. 228 *
  // Loesung: Gewicht 8,   Wert 15
  
  //final static int anzahl= 4;
  //final static int[] gewichte = {2,2,6,5,4};
  //final static int[] werte    = {6,3,5,4,6};
  //final static int capacity   = 10;
  
  // Daten http://www.proggen.org/doku.php?id=algo:knapsack
  // Loesung: Gewicht 30, Wert: 38
  /*
  final static int anzahl=10;
  final static int[] gewichte = {5,5,6,8,10,11,12,15,15,30};
  final static int[] werte    = {8,8,6,5,10,5,10,17,20,20};
  final static int capacity   = 30;
  */
  
  
  final static int anzahl= 5;
  final static int[] gewichte = {1,2,4,4,5};
  final static int[] werte    = {2,3,4,5,6};
  final static int capacity   = 10;
  
  static boolean[] auswahl = new boolean[anzahl];
  //fuer Dynamisches Programmieren:
  static int[][] tbl = new int[anzahl][capacity+1]; 
  
  public static int gewicht() {
    int g=0;
    for (int i=0;i<anzahl;i++) {
      g+=auswahl[i]?gewichte[i]:0;
    } // end of for
    return g;
  }
  
  public static int wert() {
    int w=0;
    for (int i=0;i<anzahl;i++) {
      w+=auswahl[i]?werte[i]:0;
    } // end of for
    return w;
  }
  
  public static void outputRucksack(){
    String s= new String();
    s+=String.format("Anzahl: %d Gegenst�nde%n",anzahl);
    s+=String.format("%10s","Gewicht:");
    for (int i=0; i<anzahl; i++) s+=String.format("%6d",gewichte[i]);
    s+=String.format("%n");
    s+=String.format("%10s","Wert:");
    for (int i=0; i<anzahl; i++) s+=String.format("%6d",werte[i]);
    s+=String.format("%n");
    s+=String.format("%10s","Auswahl:");
    for (int i=0; i<anzahl; i++) s+=String.format("%6s",auswahl[i]);
    s+=String.format("%n");
    s+=String.format("%nRucksackgewicht: %6d%n", gewicht());
    s+=String.format("Rucksackwert   : %6d%n", wert());
    System.out.println(s);
  }  
  
  public static void outputTabelle(){
    System.out.printf("%12s","RestKap:");
    for (int rc=0;rc<=capacity;rc++ ) System.out.printf("%4d",rc);
    System.out.printf("%n%n");
    for (int i=0;i<anzahl;i++) {
      System.out.printf("Objekt %4d:",i+1);
      for (int restcap=0;restcap<=capacity ; restcap++) 
      System.out.printf("%4d", tbl[i][restcap]);
      System.out.println();   
    } // end of for  
  }
  
  // Rekursiv, gleichzeitig wird Tabelle erzeugt
  public static int maximiere(int i, int cap) {      // Rekursiv
    if (tbl[i][cap]>0) return tbl[i][cap]; // jedoch fertig falls in Tabelle
    if (i==anzahl-1) {
      if (cap<gewichte[i]) return 0;
      else  return tbl[i][cap]=werte[i];
    } // end of (i==anzahl-1)
    else {
      if (cap < gewichte[i]) {
        return tbl[i+1][cap] = maximiere(i+1,cap);  // lasse Objekt i weg
      } // end of if
      else {
        int m1=maximiere(i+1,cap); // ohne Gegenstand i
        int m2=werte[i]+maximiere(i+1,cap-gewichte[i]); // mit Gegenstand i ;
        if (m1>m2)    // Maximum w�hlen
        return tbl[i][cap]=m1;
        else return tbl[i][cap]=m2;
      } // end of if-else
    } // end of if-else  
  } 
  
  // Es wird iterativ (ohne Rekursion) eine Tabelle erzeugt
  // aus der Tabelle wird der maximale Wert abgelesen und zurueckgeliefert.
  public static int maximiereIterativ(){
    int rc, max1,max2;
    // Zeile 0 ausfuellen fuer den letzten Gegenstand i=anzahl-1
    int i=anzahl-1;
    for (rc=0;rc<capacity+1 ;rc++ ) 
    if (rc<gewichte[i]) tbl[i][rc]=0; else tbl[i][rc]=werte[i];
    // restliche Tabelle von oben nach unten
    for (i=anzahl-2;i>=0;i--) {
      for (rc=0;rc<capacity+1 ;rc++ ){
        max1=tbl[i+1][rc];
        if (rc<gewichte[i]) tbl[i][rc]=max1;
        else {
          max2=tbl[i+1][rc-gewichte[i]]+ werte[i];
          tbl[i][rc] = max1>max2 ? max1 : max2; // das Maximum wird gew�hlt
        } // end of else 
      } // end of for rc 
    } // end of for i
    return tbl[0][capacity]; // an dieser Stelle steht das Maximum 
  }
  
  public static void select(){
    // In tbl[0][capacity] steht der maximale Wert
    int r= tbl[0][capacity];
    int cap=capacity;
    System.out.println("Maximum: "+r);
    // welche Gegenst�nde sind enthalten?
    // �ber alle Gegenst�nde i iterieren )
    int i;
    for( i = 0; i < anzahl-1; i++ ) {
      // Versuchen den aktuellen Gegenstand i aus dem Rucksack zu nehmen.
      // Stimmt der Wert an der neuen Position?
      // aktueller Wert im Rucksack - Wert des aktuellen Gegenstands 
      //       == Maximum f�r diesen Gegenstand mit dem neuen Gewicht
      if( r - werte[i] == tbl[i + 1][cap - gewichte[i]] ){
        // Gegenstand war im Rucksack
        auswahl[i]=true;
        System.out.printf("selecting     %d (%d / %d)\n",
        i , werte[i], gewichte[i] );
        r -= werte[i];
        cap-=gewichte[i];
      }
      else {
        // Gegenstand war nicht im Rucksack
        auswahl[i]=false;
        System.out.printf("NOT selecting %d (%d / %d)\n",
        i, werte[i], gewichte[i] );
      }
    } // end of for
    // Sonderfall letzter Gegenstand 
    // i = anzahl-1;
    if (tbl[i][cap]==werte[i]){ 
      // Gegenstand im Rucksack
      auswahl[i]=true;
      System.out.printf("selecting     %d (%d / %d)\n",
      i, werte[i], gewichte[i] );
    }
    else {
      // Gegenstand nicht enthalten
      auswahl[i]=false; 
      System.out.printf("NOT selecting %d (%d / %d)\n",
      i, werte[i], gewichte[i] );
    }  
  }  
  
  // ohne Zuhilfenahme der Tabelle die ausgew�hlten Objekte finden
  // mit Backtracking - Verfahren
  public static boolean selectBT(int i, int value, int cap){
    if (i==anzahl-1) {
      if (value==0){ 
        auswahl[i]=false;
        System.out.printf("Not selecting     %d (%d / %d)\n",
        i , werte[i], gewichte[i] );
        return true;
      } // end of if
      else if ((werte[i]==value) && (gewichte[i]<=cap)) {
        auswahl[i]=true;
        System.out.printf("selecting         %d (%d / %d)\n",
        i , werte[i], gewichte[i] );
        return true;  
      }  
      else {
        auswahl[i]=false;
        return false;
      }
    } // end of if i==anzahl-1
    else
    if (selectBT(i+1, value, cap)) { // ohne Gegenstand i
      auswahl[i]=false;
      System.out.printf("Not selecting     %d (%d / %d)\n",
      i , werte[i], gewichte[i] );
      return true;
    } // end of if
    else   
    if ((cap-gewichte[i]>=0)&&
    (selectBT(i+1, value-werte[i], cap-gewichte[i]))){ //  mit Gegenstand i
      auswahl[i]=true;
      System.out.printf("selecting         %d (%d / %d)\n",
      i , werte[i], gewichte[i] );
      return true;
    } // end of if-else
    else return false;
  }  
  
  public static void main (String args[]) {
    // Tabelle initialisieren
    for (int zeile=0;zeile<anzahl; zeile++) 
    for (int spalte=0;spalte<=capacity;spalte++) tbl[zeile][spalte]=0;
    // Rucksack optimal packen
    // rekursiver Aufruf
    /* int maxWert = maximiere(0,capacity); */
    //iterativer Aufruf
    int maxWert=maximiereIterativ();
    System.out.printf("Das Maximum ist %d%n%n", maxWert);
    
    
    outputTabelle();     // Kontrolle
    System.out.println();
    select();            // Auswahl der Gegenst�nde mit Tabelle
    
    
    if (selectBT(0,maxWert,capacity))//Auswahl der Gegenst�nde mit Backtracking  
    System.out.println("Erfolg");
    else  System.out.println("Ohne Erfolg");
    System.out.println();
    outputRucksack();     // Inhalt des Rucksacks ausgeben
  }
}