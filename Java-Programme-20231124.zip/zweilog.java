/**
  *
  * Description
  *
  * @version 1.0 from 16.04.2013
  * @author Bernhard Six
  */

public class zweilog {
  static double log2 = Math.log(2);
  
  public static int linksindex(int i){
    int pow, verschiebung;
    pow = (int) (Math.log(i+1)/log2); // Zweier-Log von (i+1)
    verschiebung=(int)(Math.rint((Math.round(Math.exp(log2*pow)))));//2 hoch pow
    return verschiebung+i;              
  }
  
  public static int rechtsindex(int i){
    int pow, verschiebung;
    pow = (int) (Math.log(i+1)/log2)+1;  // Zweier-Log von (i+1) +1
    verschiebung=(int)(Math.rint((Math.round(Math.exp(log2*pow)))));//2 hoch pow
    return verschiebung+i;              
  }
  
  
  public static void main(String[] args) {
    int[] li = {1,3,4,7,8,9,10,15,16,17,18,19,20,21,22};
    int[] re = {2,5,6,11,12,13,14,23,24,25,26,27,28,29,30};
    int[] neu= new int[31];
    neu[0]=0;
    for (int i=0;i<li.length ;i++ ) neu[linksindex(i)]= li[i];
    for (int i=0;i<re.length ;i++ ) neu[rechtsindex(i)]= re[i];
    
    for (int i=0;i<neu.length ;i++ ) System.out.print(neu[i]+" ");
    System.out.println();
    int[] linkerBaum = new int[neu.length/2];
    int[] rechterBaum = new int[neu.length/2];
    
    for (int i=0;i<linkerBaum.length ;i++) linkerBaum[i]=neu[linksindex(i)];
    for (int i=0;i<linkerBaum.length ;i++ ) System.out.print(linkerBaum[i]+" "); 
    System.out.println();
    for (int i=0;i<rechterBaum.length ;i++) rechterBaum[i]=neu[rechtsindex(i)];
    for (int i=0;i<rechterBaum.length ;i++ ) System.out.print(rechterBaum[i]+" "); 
    
    
    
  } // end of main                                                    7,8,
  
  
  
} // end of class zweilog
