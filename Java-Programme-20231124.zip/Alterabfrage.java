/**
  *
  * Description
  *
  * @version 1.0 from 09.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;


public class Alterabfrage {
  public static void main(String[] args) {
    double alter;
    Scanner scanner = new Scanner(System.in);
    System.out.print("Gib dein Alter ein: ");
    alter = scanner.nextDouble();

    if (alter < 6) 
      System.out.println("Kind");
    else if (alter < 18) 
      System.out.println("Jugendlicher");
    else if (alter < 65) 
      System.out.println("Erwachsener");
    else if (alter < 80) 
      System.out.println("Rentner");
    else 
      System.out.println("Greis");
    
  } // end of main
} // end of class Alterabfrage
