/**
  *
  * Description
  *
  * @version 1.0 from 02.12.2012
  * @author Bernhard Six
  */

import java.util.Scanner;
public class TestCharString {
  
  public static void main(String[] args) {
    // Variable
    char c1; 
    String s1= new String();
    char c2='�',     // Unicode 231 = 0xE7
    c3 = '\u00F1';  // Unicode 241 = 0xF1
    String s2 = "J�rg M�ller";
    Scanner scanner = new Scanner(System.in);
    // input
    System.out.print("Bitte geben Sie Ihren Vornamen und Nachnamen ein: ");
    s1=scanner.nextLine();
    System.out.print("Bitte geben Sie Ihren Kennbuchstaben ein: ");
    c1=scanner.nextLine().charAt(0);
    // processing
    // output
    System.out.println("Die Personen hei�en " + s1 + " und " + s2);
    System.out.println("Der zweite Buchstabe des Namens ist " + s1.charAt(1));
    System.out.println("Die Buchstaben sind " + c1 + " und " + c2 + " und " +c3);
    System.out.println("Der unicode des Kennbuchstabens ist " + (short)c1); 
    // Formatstring
    System.out.printf("Kennbuchstabe in Hexadezimalform %x\n", (short)c1);
    System.out.printf("Name %s und Kennbuchstabe in Dezimalform %d\n", s1, (short)c1);
    scanner.close();
  } // end of main
  
} // end of class TestCharString
