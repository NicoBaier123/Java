public class Rksk {
  private int[] gewichte = new int[10];
  private int[] werte = new int[10];
  private boolean[] auswahl = new boolean[10]; 
  private int gewicht, wert, anzahl;
  
  public Rksk(int count, int[] g, int[]w, boolean[] a) {
    gewicht=0; wert=0;
    anzahl=count;
    for (int i=0;i<anzahl ;i++ ) {
      gewichte[i]=g[i];
      werte[i]=w[i];
      auswahl[i]=a[i];
      gewicht+=auswahl[i]?gewichte[i]:0;
      wert+=auswahl[i]?werte[i]:0;
    } // end of for  
  }
  
  public Rksk(Rksk r) {
    this(r.anzahl,r.gewichte,r.werte,r.auswahl);
  }
  
  public Rksk(int count, int[] g, int[] w){
    gewicht=0; wert=0;
    anzahl=count;
    for (int i=0;i<anzahl ;i++ ) {
      gewichte[i]=g[i];
      werte[i]=w[i];
      auswahl[i]=false;
      gewicht+=auswahl[i]?gewichte[i]:0;
      wert+=auswahl[i]?werte[i]:0;
    } // end of for
  }  
  
  public void setAuswahl(int i, boolean b) {
    auswahl[i]=b;
    gewicht+=auswahl[i]?gewichte[i]:0;
    wert+=auswahl[i]?werte[i]:0;
  } 
  
  public boolean getAuswahl(int i) {
    return auswahl[i];
  }  
  
  public int getGewicht(){
    return gewicht;
  }  
  
  public int getWert(){
    return wert;
  }
  
  public Rksk optimiere(int cap){
    return optimiereRek(0,cap);
  }
  
  private Rksk optimiereRek(int i, int capacity) {
    if (i==anzahl)  return this; 
    // teste alle von r abgeleiteten Rucksaecke r1, in 
    // denen Objekt i nicht drin ist
    Rksk r1= new Rksk(this);
    r1=r1.optimiereRek(i+1, capacity);
    // wenn Objekt i noch in r passt, teste auch diese
    // abgeleiteten Rucksaecke r2
    if (gewicht+gewichte[i] <=capacity) {
      Rksk r2 = new Rksk(this);
      r2.setAuswahl(i,true);
      r2=r2.optimiereRek(i+1, capacity);
      // sollte das Ergebnis besser sein als bei r1,
      // gib diesen Rucksack zurueck
      if (r2.getWert()>r1.getWert()) return r2; 
    } // end of if
    // in allen anderen Faellen basiert das bessere Ergebnis auf r1
    return r1;
  }  
  
  public Rksk maximiere(int cap){
    Rksk[][] tbl = new Rksk [cap+1][anzahl];
    //Tabelle initialisieren
    for (int zeile=0;zeile<=cap ;zeile++) 
    for (int spalte=0;spalte<anzahl ; spalte++) 
    tbl[zeile][spalte]=null;
    return maximiereRek(0,cap, tbl); 
    // Um die Tabelle zu sehen:
    /*
    int max;             
    Rksk test = new Rksk(this);
    test=maximiereRek(0,cap, tbl); 
    for (int zeile=0;zeile<cap ;zeile++) { 
      for (int spalte=0;spalte<anzahl ; spalte++) {
        if (tbl[zeile][spalte]!=null) 
           max=tbl[zeile][spalte].getWert(); else max=-1;
        System.out.printf("%4d",max);
      }  
      System.out.println(); 
    }  
    return test;
     */
    } 
  
  private Rksk maximiereRek(int i, int cap, Rksk[][] tabelle) {
    if (i==anzahl) return this;
    int gewicht=getGewicht();
    // Erste Aenderung zum Backtracking: wenn schon mal beim Packen des Teils
    // i in einen Rucksack mit einem bestimmten Gewicht eine optimale Loesung
    // fuer die Teile i bis anzahl-1 berechet wurde, koennen wir diese
    // wiederverwenden:
    if (tabelle[gewicht][i]!=null) {
      for (int j=i; j < anzahl; j++)
      setAuswahl(j,tabelle[gewicht][i].getAuswahl(j));
      return this;
    } // end of if
    // Nur wenn dies nicht Fall ist, muessen wir mit der Rekursion fortfahren:
    Rksk r1 = new Rksk(this);
    r1 = r1.maximiereRek(i+1, cap, tabelle);
    if (gewicht+gewichte[i] <= cap) {
      Rksk r2 = new Rksk(this);
      r2.setAuswahl(i,true);
      r2 = r2.maximiereRek(i+1,cap,tabelle);
      if (r2.getWert() > r1.getWert()) r1=r2;
    }  
    // Zweite Aenderung zum Backtracking: wir merken uns den optimal gepackten
    // Rucksack fuer diese Situation
    tabelle[gewicht][i] = r1;
    return r1;  
  } 
  
  public String toString(){
    String s= new String();
    s+=String.format("Anzahl: %d Gegenst�nde%n",anzahl);
    s+=String.format("%10s","Gewicht:");
    for (int i=0; i<anzahl; i++) s+=String.format("%6d",gewichte[i]);
    s+=String.format("%n");
    s+=String.format("%10s","Wert:");
    for (int i=0; i<anzahl; i++) s+=String.format("%6d",werte[i]);
    s+=String.format("%n");
    s+=String.format("%10s","Auswahl:");
    for (int i=0; i<anzahl; i++) s+=String.format("%6s",auswahl[i]);
    s+=String.format("%n");
    s+=String.format("%nRucksackgewicht: %6d%n",gewicht);
    s+=String.format("Rucksackwert   : %6d%n",wert);
    return s;
  }
}