import java.util.*;

class CoinChange1 {
  public static int solve(Stack<Integer> coins, int change) {
    if (change == 0) return 1;
    int sum = 0;
    while(!coins.empty()) {
      int coin = coins.peek();
      if (coin > change) break; //optimization
      sum += solve((Stack<Integer>)coins.clone(), change - coin);
      coins.pop();
    }
    return sum;
  }
  
  public static void main(String[]args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("enter the number of coins");
    int n = sc.nextInt();
    Stack<Integer> coins = new Stack<Integer>();
    System.out.println("input the value of each coin");
    for(int i = 1; i <= n; i++)
    coins.add(sc.nextInt());
    Collections.sort(coins);
    Collections.reverse(coins);
    System.out.println("input the amount of change");
    int change = sc.nextInt();
    System.out.printf("there are %d ways to make change for %d cents\n", solve(coins, change), change);
  }
}

