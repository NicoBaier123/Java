public class RucksackDPTest {
  
  public static void main (String args[]) {
    if (args.length == 1)
    anzahlObjekte = Integer.parseInt(args[0]);
    kapazitaet = (int)(anzahlObjekte * MAX_GEWICHT / 4);
    
    auswahlObjekte = erzeugeObjekte();
    System.out.println(objekteToString(auswahlObjekte));
    System.out.println("Kapazitaet: " + kapazitaet);
    
    Rucksack r3 = packeOptimalmitBacktracking();
    System.out.println("Optimal mit Backtracking: " + r3 );
    
    Rucksack r4 = packeMitDynamischerProgrammierung();
    System.out.println("Optimal mit DP: " + r4 );    
  }
}