/**
  *
  * Description
  *
  * @version 1.0 from 11.01.2013
  * @author Bernhard Six
  */
import java.util.Arrays;

public class Reihenfolge1 {
  
  static int[] order(int[] array){
    int[] seq =Arrays.copyOf(array,array.length);
    int[] ordered = new int[array.length];
    int max;
    for (int i=0;i<array.length ;i++ ) {
      max=0;
      for (int j=0;j<array.length ;j++ ) {
        if (seq[j]>seq[max]) {
          max=j;    
        } // end of if    
      } // end of for j
      seq[max]=Integer.MIN_VALUE;
      ordered[i]=max;
      } //end of i
      return ordered;
    }
    
    public static void main(String[] args) {
      int[] seq={3,1,4,2,5,7};
      int[] reihenfolge = new int[seq.length];
      System.out.println(Arrays.toString(seq));
      reihenfolge=order(seq);
      System.out.println(Arrays.toString(reihenfolge));
    } // end of main
    
  } // end of class Reihenfolge
