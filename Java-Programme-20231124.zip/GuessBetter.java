public class GuessBetter {
  public static void main(String[] args) {
    int number = (int) ((Math.random() * 5) + 1);
    int guess;
    do {
      do { 
        System.out.println("Welche Zahl denke ich mir zwischen 1 und 5?");
        guess = new java.util.Scanner(System.in).nextInt();  
      } while ((guess < 1) || (guess > 5) );
      if (number == guess) {
        System.out.println("Super getippt!");
      } // end if
    }  while (guess!=number); // end do-while
  } // end main
}  // end class                                                                
