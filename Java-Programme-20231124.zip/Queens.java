/**
 * Java-Programm zum L�sen des n-Damen-Problems
 *
 * @author Bernhard Six (nach Vorlage von Daniel Gronau)
 * @version 1.0 vom 12.01.2012
 */

import java.util.Stack;
import java.util.Scanner;
 
public class Queens {
  
  //ist die Stellung zul�ssig?
  public static boolean isValid(Stack<Integer> pos) {
    if (pos.isEmpty()) {
      return true;
    }
    Stack<Integer> s = new Stack<Integer>();
    s.addAll(pos);
    int first = s.pop();
    int c = 0; //diagonale Abweichung
    while (!s.isEmpty()) {
      int elem = s.pop();
      c++;
      if (elem == first || Math.abs(elem - first) == c) {
        return false;
      }
    }
    return true;
  }
  
  //n�chster Schritt ist forward bei true und backward f�r false
  public static boolean backward(int n, Stack<Integer> pos) {
    if (pos.isEmpty()) {
      return false;
    } else {
      int last = pos.pop();
      //alle M�glichkeiten in dieser Reihe durchprobiert?
      if (last == n - 1) {
        return false; //zur�ck
      } else {
        //n�chste Alternative setzen
        pos.push(last + 1);
        return true; //vorw�rts
      }
    }
  }
  
  //n�chster Schritt ist forward bei true und backward f�r false
  public static boolean forward(int n, Stack<Integer> pos) {
    if (isValid(pos)) {
      //L�sung gefunden?
      if (pos.size() == n) {
        println(pos);
        pos.pop();
        return false; //zur�ck: weitere L�sungen suchen
      } else {
        pos.push(0);
        return true; //vorw�rts
      }
    } else {
      //Stellung unzul�ssig
      return false; //zur�ck
    }
  }
  
  //f�hrt die Schritte aus
  private static void step(int n, Stack<Integer> pos) {
    boolean result = true;
    while (!pos.isEmpty() || result) {
      result = result ? forward(n, pos) : backward(n, pos);
    }
  }
  
  //ordentliche Ausgabe
  private static void println(Stack<Integer> pos) {
    String s="";
    for (int i = 0; i < pos.size(); i++) {
      s+=pos.get(i);
      if (i<pos.size()-1) s+="-";
    }   
    System.out.println(s);
    
    /*  //Alternative Ausgabe:
    for (int i = 0; i < pos.size(); i++) 
    System.out.print("" + (char) (pos.get(i) + 'a') + (i + 1) + " ");   
    System.out.println(); 
    */
  }
  
  public static void solve(int n) {
    step(n, new Stack<Integer>());
  }
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Gib Anzahl der Damen ein: ");
    int anzahl = scanner.nextInt();
    solve(anzahl);
  }
}