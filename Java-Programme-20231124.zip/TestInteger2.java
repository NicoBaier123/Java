/**
  *
  * Description
  *
  * @version 1.0 from 01.12.2012
  * @author Bernhard Six
  */
  
import java.util.Scanner;

public class TestInteger2 {
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner (System.in);
    byte z1,z2,z;
    // input
    System.out.print("Erste Zahl: ");  //zwischen -128 und 127
    z1 = scanner.nextByte();
    System.out.print("Zweite Zahl: ");
    z2 = scanner.nextByte();
    z= (byte) (z1+z2);      //120 + 100 ?
    System.out.println("Die Summe ist " + z);
  } // end of main
  
} // end of class TestInput
