/**
  *
  * Description
  *
  * @version 1.0 from 20.02.2013
  * @author Bernhard Six
  */

 import java.util.Scanner;

public class Lakritz {
  
  public static void main(String[] args) {
    int gummi, lakritz, zufall, zug1,zug2;
    Scanner scanner = new Scanner(System.in); 
    System.out.print("Anzahl Gummib�rchen: ");
    gummi = scanner.nextInt();
    System.out.print("Anzahl Lakritz: ");
    lakritz = scanner.nextInt();
    System.out.println("     Zug   Gummi Lakritz");
    System.out.printf("%8s%8s%8S\n", "",gummi,lakritz);
    while (gummi+lakritz>=2) {
      zufall= (int) (Math.random()*(gummi+lakritz))+1;
      //System.out.println(zufall);
      if (zufall<=gummi)zug1=0; else zug1=1;  // 0 ist gummi
      zufall= (int) (Math.random()*(gummi+lakritz-1)) +1;
      //System.out.println(zufall);
      if (zug1==0 && zufall<gummi) zug2=0;
      else 
      if (zug1==1 && zufall<=gummi) zug2=0;
      else 
      zug2=1;
      if (zug1==0 && zug2==0) {
        gummi-=2;
        lakritz++;
      } // end of if
      else  lakritz--;
      System.out.printf("%4s%4s%8s%8S\n", zug1,zug2,gummi,lakritz);    
    } // end of while
    
    
  } // end of main
  
} // end of class Lakritz
