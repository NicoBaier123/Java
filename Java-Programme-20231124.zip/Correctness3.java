 /**
  * Korrektheit
  */
import java.util.Scanner;
public class Correctness3 {
  
  public static void main(String argv[]) {
    Scanner scanner = new Scanner(System.in);
    int n, x, y, z; 
    do { 
      System.out.print("Ganze Zahl gr��er gleich Null: ");
      n = scanner.nextInt(); 
    } 
    while (n < 0); 
    x = 2; y = n; z = 1; 
    while (y > 0) { // Q = y > 0 
      if (y % 2 == 1) { 
        z = z * x; 
        y = y - 1; 
      } else { 
        x = x * x; 
        y = y/2;   
      } 
    }    
    System.out.println ("Das Ergebnis ist " + z);    
    scanner.close();
  }
}