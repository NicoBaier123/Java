/**
  *
  * Description
*   Labyrinth mit Backtracking                                                                 
  * @version 1.0 from 12.01.2013
  * @author Bernhard Six
  */

import java.util.Arrays;

public class Labyrinth {
  static int anzahlLoesungen=0;
  static int startZeile=3;
  static int startSpalte=5;
  
  final static int spaltenAnzahl=9;
  final static int zeilenAnzahl=7;
  
  static char[][] laby = {                               
    {'X','X','X','X',' ','X','X','X','X'},    // Zeile 0
    {'X',' ','X',' ',' ',' ',' ',' ','X'},
    {'X',' ','X','X',' ','X','X','X','X'},
    {'X',' ',' ',' ',' ',' ',' ',' ','X'},
    {'X',' ','X','X','X','X','X',' ','X'},
    {' ',' ','X',' ',' ',' ',' ',' ','X'},
    {'X','X','X','X','X',' ','X','X','X'}};  // Zeile 6
  
  static void zeichne(char [][] lab){
    System.out.println();
    for (int zeile=0; zeile<zeilenAnzahl ;zeile++ ) {
      for (int spalte=0; spalte<spaltenAnzahl ;spalte++ ) {
        System.out.print(lab[zeile][spalte]);
      } // end of for spalte
      System.out.println();
    } //end of for zeile; 
    
  }    
  
  static void findeWeg(int z, int s, char[][] lab){ //z=Zeile,s=Spalte
    char[][] labNeu=Arrays.copyOf(lab,lab.length);
    if (frei(labNeu,z,s)) {            // keine Mauer, nicht markiert
      markiere(labNeu,z,s);            // falls leer, Markierung 
      if (keinAusgang(z,s))  {         // Ausgang noch nicht gefunden  
        findeWeg(z+1,s,labNeu);        // unten weitersuchen
        findeWeg(z,s+1,labNeu);        // rechts weitersuchen
        findeWeg(z-1,s,labNeu);        // oben weitersuchen
        findeWeg(z,s-1,labNeu);        // links weitersuchen
      } // end of if
      else {                            // Ausgang gefunden
        zeichne(labNeu);                // Weg ausgeben
        anzahlLoesungen++;              // Anzahl der gefundenen Wege erh�hen
      } // end of if-else
      entferneMarkierung(labNeu,z,s);   // R�cknahme der Markierung                
    }
  }   
  
  static boolean frei(char [][] lab,  int z, int s) {
    return (lab[z][s]==' ');
  }
  
  static void markiere(char[][] lab, int z, int s) {
    lab[z][s]='*';
  }  
  
  static void entferneMarkierung(char[][] lab, int z, int s) {
    lab[z][s]=' ';
  }
  
  static boolean keinAusgang(int z, int s){
    return (z>0 && s>0 && z<zeilenAnzahl-1 && s<spaltenAnzahl-1);
  }
  
  public static void main(String[] args) {
    zeichne(laby);
    findeWeg(startZeile,startSpalte,laby);
    System.out.println("\nEs wurden "+anzahlLoesungen+" Wege gefunden.");      
  } // end of main
  
} // end of class Labyrinth
