public class FibonacciDP {
  private long[] tbl= new long[100];
  
  public FibonacciDP() {
    for (int i=2;i<100 ;i++ )tbl[i]=0;
    tbl[0]=1;
    tbl[1]=1;
  }  
  
  public long fibonacci(int n) {
    if(n > 91) throw new IndexOutOfBoundsException("Fibonacci mit n > 91 not supported!");     
    if (tbl[n]>0)  return tbl[n];
    return tbl[n]=fibonacci(n-1)+fibonacci(n-2);   
  } 
  
  public String toString(){
    String s= new String();
    for (int i=0;i<100;i++ ) {
      if (tbl[i]==0) break;
      s+=String.format("%5d",tbl[i]);
    } // end of for
    s+=String.format("%n");
    return s;
  }  
}