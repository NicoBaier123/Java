public class RucksackRekTest {
  
  public static void main (String args[]) {
    /* Daten Saake/Sattler S. 228
    int anzahl= 5;
    int[] gewichte = {2,2,6,5,4};
    int[] werte = {6,3,5,4,6};
    */
    
    // Daten http://www.proggen.org/doku.php?id=algo:knapsack
    int anzahl=10;
    int[] gewichte = {5,5,6,8,10,11,12,15,15,30};
    int[] werte    =  {8,8,6,5,10,5,10,17,20,20};
    //leerer Rucksack mit den gegebenen Gegenst�nden
    Rksk myRucksack = new Rksk(anzahl,gewichte,werte);
    System.out.println(myRucksack);
    
    // er soll bis zur Kapazit�tsgrenze optimal gef�llt werden:
    int kapazitaet = 30;  
    myRucksack=myRucksack.optimiere(kapazitaet); // Backtracking
    //myRucksack=myRucksack.maximiere(kapazitaet);  // Dynamische Tabelle
    System.out.println(myRucksack);  
  }
}