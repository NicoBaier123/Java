  public class Hrek {
  
  public static int hrek(int n) {
    //n>0
    // berechnet n*(n-1)
    if (n==1) return 0;
    return 2*(n-1) + hrek(n-1);
  }
  
  
  public static void main(String[] args) {
     System.out.println(hrek(9)); 
  } // end of main
  
} // end of class Hrek