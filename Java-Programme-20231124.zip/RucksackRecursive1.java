/**
  *
  * Description
  *
  * @version 1.0 from 11.01.2013
  * @author Bernhard Six
  */

import java.util.Arrays;
public class RucksackRecursive1 {
  // Eingabeparameter
  static double capacity = 8.0; 
  static int gesamtzahl=4;
  static double[] weight ={6,2,2,5};
  static double[] value = {5,3,6,4};
  
  static double rucksack(int i, double currentCapacity){ 
    double a,b;
    if (i==gesamtzahl) return 0;
    a=rucksack(i+1, currentCapacity);
    // Passt Gegenstand i+1 noch rein?
    if (currentCapacity >= weight[i]) { 
      b=rucksack(i+1, currentCapacity-weight[i])+value[i];
      if (b>a) return b;
      }
    return a;         
  } // of rucksack
  
  public static void main(String[] args) {
    
    // Ausgabeparameter
    double maxValue;
    
    // Aufruf mit Gegenstand 0 und Gesamtkapazit�t
    maxValue=rucksack(0,capacity);
    System.out.println("Der Maximalwert bei einer Kapazit�t von "+ capacity +" kg ist " +maxValue);
  } // end of main
  
} // end of class RucksackRecursive
