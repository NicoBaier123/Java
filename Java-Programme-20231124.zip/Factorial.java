/**
  *
  * Description
  *
  * @version 1.0 from 09.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;


public class Factorial {
  static int factorial(int n) {
    if (n == 0) {
      return 1;
    } // end of if
    else {
      return n * factorial(n - 1);
    } // end of if-else
  }
  
  static int factorialiter(int n){
    int fak=1;
    for (int i=1; i<=n; i++ ) fak=fak*i;
    return fak;
  }  
  
  
  public static void main(String[] args) {
    int number;
    int fac;
    Scanner scanner = new Scanner(System.in);
    do {
      System.out.print("Gib eine ganze Zahl zwischen 0 und 10 ein: ");
      number = scanner.nextInt();
    } while ((number < 0) || (number > 10));
    System.out.printf("Die Fakultaet von %d ist %d.\n", number,
                      factorialiter(number));
  } // end of main
} // end of class Factorial
