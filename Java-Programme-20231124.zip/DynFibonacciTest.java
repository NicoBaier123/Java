import java.util.Scanner;
public class DynFibonacciTest {
  
  public static void main(String[] args) {
    int number;
    DynFibonacci df= new DynFibonacci();
    
    System.out.println("Fibonaccifolge neu: "+df);
    Scanner scanner = new Scanner(System.in);
    do {
      System.out.print("Welche Nummer der Fibonaccifolge (zwischen 0 und 91): ");
      number = scanner.nextInt();
    } while ((number < 0) || (number > 91));
    System.out.printf("Die %d. Fibonaccizahl ist %d.\n", number,
    df.fibonacci(number));
    
    System.out.println("Fibonaccifolge jetzt: "+df);
    
    for (int i=0;i<92;i++) System.out.printf("%3d %10d\n",i, df.fibonacci(i));
    
  } // end of main
} // end of class DynfibonacciTest
