/**
 * Java-Programm zum L�sen des n-Damen-Problems
 *
 * @author Bernhard Six (nach Vorlage von Daniel Garmann)
 * @version 1.0 vom 12.01.2012
 */
 
import java.util.Scanner; 
public class DamenSix {
  static private int damenAnzahl;           // Damenanzahl
  static private boolean[] zeileBedroht;    // Zeile des Brettes
  static private boolean[] aufDiagBedroht;  // Aufw�rtsdiagonalen
  static private boolean[] abDiagBedroht;   // Abw�rtsdiagonalen
  static private int[] damen;               // merken, wo die Dame jeder Spalte steht
  static private int loesungsAnzahl = 0;    // Anzahl der L�sungen
  static private String loesungen = "";     // Hier wird die R�ckgabe gesammelt.
  
  static public void init(int anzahl) {
    damenAnzahl = anzahl;
    zeileBedroht = new boolean[damenAnzahl];
    aufDiagBedroht = new boolean[2 * damenAnzahl-1];
    //Es wird festgehalten, ob in einer steigenden Diagonale schon eine
    //Dame steht. F�r alle Positionen einer solchen Dame gilt, dass zeile+spalte
    //konstant ist. Betrachtet man den Term zeile+spalte, dann
    //bewegt sich der index zwischen 0 und 2*damenzahl-1
    abDiagBedroht = new boolean[2 * damenAnzahl-1];
    //Es wird festgehalten, ob in einer bestimmten fallenden 
    //Diagonalen schon eine Dame steht. F�r alle Positionen einer solchen
    //Diagonalen gilt, dass spalte-zeile konstant ist. Der Index bewegt sich
    //zwischen -(damenAnzahl-1)  und damenAnzahl-1, 
    //weshalb stets spalte-zeile + damenAnzahl-1 gerechnet wird.
    damen = new int[damenAnzahl];
    
    // Erst mal alles auf false, d.h. alles frei
    for (int i = 0; i < damenAnzahl; i++) zeileBedroht[i] = false;
    for (int i = 0; i < (2 * damenAnzahl) - 1; i++)aufDiagBedroht[i] = false;
    for (int i = 0; i < (2 * damenAnzahl) - 1; i++) abDiagBedroht[i] = false;
    for (int i = 0; i < damenAnzahl; i++)  damen[i] = -1;
  }
  
  static private void setzeDame(int x, int y) {
    zeileBedroht[x] = true;
    aufDiagBedroht[x+y] = true;
    abDiagBedroht[x-y+damenAnzahl-1] = true;
    damen[y] = x;
  }
  
  static private void loescheDame(int x, int y) {
    zeileBedroht[x] = false;
    aufDiagBedroht[x+y] = false;
    abDiagBedroht[x-y+damenAnzahl-1] = false;
    damen[y] = -1;
  }
  
  static private boolean bedroht(int x, int y) {
    return (zeileBedroht[x] || aufDiagBedroht[x+y] ||
    abDiagBedroht[x - y+damenAnzahl-1]);
  }
  
  static private void dameSetzen(int spalte) {
    for (int zeile = 0; zeile < damenAnzahl; zeile++) {
      if (!bedroht(zeile, spalte)) {
        setzeDame(zeile, spalte);
        if (spalte < damenAnzahl-1) {
          dameSetzen(spalte + 1);
        } else {
          println(damen);
          loesungsAnzahl++;
        }
        loescheDame(zeile, spalte);
      } // end of if
    } // end of for
  } // end of dameSetzen
  
  static private void println(int[] array) {
    String s = "";
    for (int spalte = 0; spalte < damenAnzahl; spalte++) {
      s = s + array[spalte];
      if (spalte < damenAnzahl-1) s = s + "-";
    }
    System.out.println(s);
  }
  
  static public void startDame(int anzahl) {
    init(anzahl);
    dameSetzen(0);
    System.out.println("\n----------------------------\n");
    System.out.println("Es ergaben sich " + loesungsAnzahl + " L�sungen.");
    return;  
  }
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Gib Anzahl der Damen ein: ");
    int anzahl = scanner.nextInt();
    System.out.println("\n----------------------------\n");
    startDame(anzahl);    
  } // end of main
}

