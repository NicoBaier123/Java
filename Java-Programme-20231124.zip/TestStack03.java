/**
  *
  * Description
  *
  * @version 1.0 from 11.01.2013
  * @author Bernhard Six
  */

import java.util.Stack;
import java.util.Scanner;
import java.util.Arrays;

public class TestStack03 {
  
  public static void main(String[] args) {
    Stack<Double> stack  = new Stack<Double>();
    String line;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Gib eine Kommazahl je Zeile ein. Leere Eingabe beendet die Eingabe.");
    int i=1;
    // so lange Zeilen einlesen und dem Stack hinzuf�gen bis leere Eingabe
    do {
      System.out.printf("\n %3d. Zahl: ", i++);
      line=scanner.nextLine();
      if (!line.isEmpty()){
        try {
          Double.parseDouble(line); 
        } catch(Exception e){ 
          System.out.println("\nFalsche Eingabe");
          i--;
          continue;
        } 
        stack.push(Double.parseDouble(line));
      }
    } while (!line.isEmpty() );
    scanner.close();
    System.out.println(i-2+" Elemente");
    if (stack.empty()) System.out.println("\nLeere Liste");
    else {
      double[] feld = new double[i-2];
      for (i=0;i<feld.length;i++ ) feld[i]=stack.pop();
      Arrays.sort(feld);
      System.out.println("\nSortierte Liste: "+ Arrays.toString(feld));
      int mitte=(feld.length-1)/2;
      System.out.println("\nDer Median ist " + feld[mitte]);
    } // end of if-else
  }  
}
