import java.util.Scanner;
public class FibonacciDPTest {
  
  public static void main(String[] args) {
    int number;
    FibonacciDP fibDP = new FibonacciDP();
    
    System.out.println("Fibonaccifolge neu: "+fibDP);
    Scanner scanner = new Scanner(System.in);
    do {
      System.out.print("Welche Nummer der Fibonaccifolge (zwischen 0 und 91): ");
      number = scanner.nextInt();
    } while ((number < 0) || (number > 91));
    System.out.printf("Die %d. Fibonaccizahl ist %d.\n", number,
    fibDP.fibonacci(number));
    
    System.out.println("Fibonaccifolge jetzt: "+fibDP);
    
    for (int i=0;i<92;i++) System.out.printf("%3d %10d\n",i, fibDP.fibonacci(i));
    
  } // end of main
} // end of class FibonacciDPTest
