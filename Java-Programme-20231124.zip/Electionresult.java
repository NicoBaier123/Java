public class Electionresult {
  public static void main(String[] args) {
    // definition of variables
    int votes1,votes2,votes3;
    double sum, fraction1,fraction2,fraction3;
    
    // input
    votes1 = InOut.readInt("Steves votes: ");
    votes2 = InOut.readInt("Barbaras votes: ");
    votes3 = InOut.readInt("Robs votes: ");
    
    // processing
    sum = votes1 + votes2 + votes3;
    fraction1 = votes1 / sum * 100;
    fraction2 = votes2 / sum * 100;
    fraction3 = 100 - fraction1 - fraction2;
    
    // output
    System.out.println("Steves fraction: " + fraction1 + " %");
    System.out.println("Barbaras fraction: " + InOut.format2(fraction2)+" %");
    System.out.println("Robs fraction: " + InOut.formatN(fraction3, 1) +" %");
    InOut.readln();
  }
}
