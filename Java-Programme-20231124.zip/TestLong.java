/**
  *
  * Description
  *
  * @version 1.0 from 01.12.2012
  * @author Bernhard Six
  */

import java.util.Scanner;
public class TestLong {
  
  public static void main(String[] args) {
    //Variables
    Scanner scanner = new Scanner (System.in);
    long z1,z2,z;
    // Input
    System.out.print("Erste Zahl: "); 
    z1 = scanner.nextLong();
    System.out.print("Zweite Zahl: ");
    z2 = scanner.nextLong();
    // Processing
    z = z1 + z2;          
    // Output
    System.out.println("Die Summe ist " +z);
    scanner.close();
  } // end of main
  
} // end of class TestLong
