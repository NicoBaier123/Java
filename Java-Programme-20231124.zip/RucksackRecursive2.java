/**
  *
  * Description
  *
  * @version 1.0 from 11.01.2013
  * @author Bernhard Six
  */
import java.util.Arrays;


public class RucksackRecursive2 {
  // Eingabeparameter
  static double capacity = 8.0;
  static int gesamtzahl=4;
  static double[] weight ={6,2,2,5};
  static double[] value = {5,3,6,4};
  //static int gesamtzahl = 2;
  //static double[] weight = { 3,8 };
  //static double[] value = { 13,17 };
  
  static double wert(boolean[] array){
    double w=0.0;
    for (int i=0;i<gesamtzahl;i++ ) 
    if (array[i]) w+=value[i];
    return w;  
  }
  
  static double gewicht(boolean[] array){
    double g=0.0;
    for (int i=0;i<gesamtzahl;i++ ) 
    if (array[i]) g+=weight[i];
    return g;  
  }
  
  //rekursives Methode
  static boolean[] rucksack(int i, boolean[] solution) {
    boolean[] solution1 = new boolean[gesamtzahl];  
    boolean[] solution2 = new boolean[gesamtzahl];  
    
    if (i == gesamtzahl) return solution;   
    
    // Aufruf mit bisheriger Belegung und dem n�chsten Gegenstand
    // ohne Gegenstand i 
    for (int j=0;j<gesamtzahl;j++ ) solution1[j]=solution[j];
    solution1=rucksack(i+1, solution1);
    // passt Gegenstand i noch rein?
    if (gewicht(solution)+weight[i]<=capacity) { //ja
      // bisherige Belegung wird an Stelle i ge�ndert
      for (int j=0;j<gesamtzahl;j++ ) solution2[j]=solution[j];
      solution2[i]=true;
      //Aufruf mit ge�nderter Belegung und dem n�chsten Gegenstand
      solution2=rucksack(i+1, solution2);
      if (wert(solution2)> wert(solution1)) return solution2;  
    } // end of if
    return solution1; // die optimale Belegung wird zur�ckgegeben 
  } // end of rucksack
  
  
  public static void main(String[] args) {  
    double maxValue = 0;
    double maxWeight = 0;
    boolean[] solution = new boolean[gesamtzahl];  
    
    System.out.println("Kapazit�t: " + capacity);
    System.out.println("Gewicht: "+Arrays.toString(weight));
    System.out.println("Wert:    "+Arrays.toString(value));
    
    // Aufruf mit Gegenstand 0 und leerer Belegung 
    for (int i = 0; i < gesamtzahl; i++) solution[i] = false;
    solution = rucksack(0, solution);
    
    System.out.println("L�sung:  "+Arrays.toString(solution));     
    System.out.println("Maximalgewicht " + gewicht(solution) + " Maximalwert " + wert(solution));
  } // end of main
} // end of class RucksackRecursive
