import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;

public class Median {
  
  public static void main(String[] args) {
    ArrayList<Double> liste = new ArrayList <Double>();
    String line;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Gib eine Zahl je Zeile ein. Leere Eingabe beendet die Eingabe.");
    int i=1;
    do {
      System.out.printf("\n %3d. Zahl: ", i++); 
      line=scanner.nextLine();
      if (!line.isEmpty()){ 
        try {Double.parseDouble(line); 
        } catch(Exception e){ 
          System.out.println("\nFalsche Eingabe");
          i--;
          continue;
        }
        liste.add(Double.parseDouble(line));
      }
    } while (!line.isEmpty()) ;
    scanner.close();
    if (liste.size()==0) {
      System.out.println("\nLeere Liste");
    } 
    else {
      double[] feld = new double[liste.size()];
      for (i=0;i<feld.length;i++ ) feld[i]=(double)liste.get(i);
      Arrays.sort(feld);
      System.out.println("\nSortierte Liste: "+ Arrays.toString(feld));
      int mitte=(feld.length-1)/2;
      System.out.println("\nDer Median ist " + feld[mitte]);
    } // end of if-else
  }  
}
