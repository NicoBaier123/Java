/**
  *
  * Description
  *
  * @version 1.0 from 15.12.2012
  * @author Bernhard Six
  */

public class SeqSearch {
  public final static int NO_KEY = -1;
  
    static int search(int[] array, int key){
      for (int i=0;i<array.length ; i++ ) 
         if (array[i]==key) return i;
      return NO_KEY; 
    }
  
    static int searchRek(int initpos, int[] array, int key){
     if (initpos>=array.length) return NO_KEY;
       else if (array[initpos]==key) return initpos;
       else return searchRek(++initpos, array, key);
    }  
    
    public static void main(String[] args) {
      int[] f= {2,4,5,6,7,8,9,11};
      System.out.print("Nach welchem Element soll gesucht werden? ");
      int key = new java.util.Scanner(System.in).nextInt() ;
      System.out.println("Das gesuchte Element befindet sich an Pos "+ searchRek(0,f,key) );
    } // end of main
  } // end of class SeqSearch
