/**
  *
  * Description
  *
  * @version 1.0 from 01.12.2012
  * @author Bernhard Six
  */
import java.util.Scanner;

public class TestScanner {
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner (System.in);
    int z1,z2,z;
    String name;
    
    // input
    System.out.print("Wie hei�t du: ");
    name= scanner.nextLine();
    System.out.print("Erste Zahl: ");
    z1=scanner.nextInt();
    System.out.print("Zweite Zahl: ");
    z2=scanner.nextInt();
    
    //processing
    z=z1+z2;
    
    //output
    System.out.println(name+ ", deine Summe ist " + z);
    
  } // end of main
  
} // end of class TestScanner
