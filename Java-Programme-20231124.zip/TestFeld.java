/**
  *
  * Description
  *
  * @version 1.0 from 05.12.2012
  * @author Bernhard Six
  */

public class TestFeld {
  
  public static void main(String[] args) {
    int[] ziffer = {0,1,2,3,4,5,6,7,8,9};
    int[] nummer = new int[3];
    nummer[0]=2; nummer[1]=3; nummer[2]=5;
    int[] zahl;
    zahl=nummer;
    System.out.println("Die Anzahl der Ziffern ist " + ziffer.length);
    System.out.println("Die dritte Ziffer ist " + ziffer[2]);
    System.out.println("Die dritte Nummer ist " + nummer[2]);
    zahl[2]=7;
    System.out.println("Die dritte Nummer ist " + nummer[2]);
    System.arraycopy(ziffer,8,nummer,0,2);
    System.out.println("Die erste Nummer ist " + nummer[0]);  
  } // end of main
  
} // end of class TestFeld
