/**
  *
  * Description
  *
  * @version 1.0 from 20.02.2013
  * @author Bernhard Six
  */

public class Prod_appl {
  
  static int prod(int x, int y){
    if (x==0) return 0;
    else 
    if (x>0) return prod(x-1,y)+y;
    else 
      return -prod(-x,y); 
  }  
  
  public static void main(String[] args) {
    System.out.println("Das Produkt ist " + prod (3,-5));
    
  } // end of main
  
} // end of class Prod_appl
