 /**
  * Eine Methode r, deren Korrektheit bewiesen werden soll
  */
import java.util.Scanner;
public class Correctness5 {
  
  public static int h(int n){
    // n > 0
    int i=1, s=0;
    // s=(i-1)*i && i<=n
    while (i < n) {
      // s=(i-1)*i && i < n 
      s=s+2*i;
      // s= (i-1)*i +2*i  && i <n
      // s= (i+1)*i && i <n
      i=i+1;
      // s= (i-1)*i  && i < =n
    }
    // s= (i-1)*i && i <= n && i>=n
    // s= (n-1)*n
    return s;
  }
  
  public static int k(int a, int b){
    // a >= b >= 0
    int s=0, i=b;
    // s=(i-b)*(i-1+b)&& i<=a+1
    while (i <= a) {  
      s=s+2*i;
      i=i+1;
    }
    // s=(i-b)*(i-1+b)&& i=a+1
    //s=(a+1-b)*(a+b)= (a-b)*(a+b)+(a+b)
    s=s-(a+b);
    //s= (a-b)*(a+b)
    return s;  
  }
  
  
  
  
  public static int rrek(int n, int m) {
    // n>=0, m>0
    if (n<m) return n;
    else return rrek(n-m,m);  
  }  
  
  public static int q(int n, int m){
    //n>=0, m>0 
    int s=0;
    int q=-1;
    while (s<=n) {
      q=q+1;
      s=s+m;
    } // end of while
    return(q);     
  }
  
  public static int qrek(int n, int m) {
    //n>=0, m>0
    if (n<m) return 0;
    else return 1+qrek(n-m,m);
  }
  
  public static int mul(int x, int y) {
    // x,y > 0  
    int p=0, a=x, b=y;
    //x*y = a*b+p;
    while (a>0) {
      if (a%2==1) p=p+b;
      a=a/2;
      b=b*2;
    } // end of while
    return p;
  }  
  
  public static int pot(int x, int y) {
    // x,y > 0  b=basis, n=exponent
    int p=1, b=x, n=y;
    //x^y = b^n*p;
    while (n>0) {
      if (n%2==1) p=p*b;
      n=n/2;
      b=b*b;
    } // end of while
    return p;
  }  
  
  public static int potrek (int b, int n) {
    // b,n >=0   b=basis, n=exponent
    int t1,t2;  // lokale tempor�re Variable
    if (n==0) return 1;
    t1=potrek(b,n/2); t2=t1*t1;
    if (n%2==0) return t2; else return b*t2;
  }    
    
  public static void main(String argv[]) {
    Scanner scanner = new Scanner(System.in);
    int i,j;
    do {  
      System.out.print("Ganze Zahl gr��er gleich Null: ");
      i= scanner.nextInt(); 
    } while (i < 0);
    System.out.println(" Das Ergebnis ist " + h(i));
    /*
    
    do {  
      System.out.print("Ganze Zahl gr��er Null: ");
      j= scanner.nextInt(); 
    } while (j <= 0);
    
    System.out.printf("\npot(%d,%d) = %d.\n",i,j,potrek(i,j));
     */
    scanner.close();
    }
}