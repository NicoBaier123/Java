/**
  *
  * Description
*   Labyrinth mit Backtracking                                                                 
  * @version 1.0 from 12.01.2013
  * @author Bernhard Six
  */

import java.util.Arrays;

public class LabyrinthZeichnen {
  static int anzahlLoesungen=0;
  static int startZeile=3;
  static int startSpalte=5;
  
  final static int spaltenAnzahl=9;
  final static int zeilenAnzahl=7;
  
  static char[][] laby = {                               
    {'X','X','X','X',' ','X','X','X','X'},    // Zeile 0
    {'X',' ','X',' ',' ',' ',' ',' ','X'},
    {'X',' ','X','X',' ','X','X','X','X'},
    {'X',' ',' ',' ',' ',' ',' ',' ','X'},
    {'X',' ','X','X','X','X','X',' ','X'},
    {' ',' ','X',' ',' ',' ',' ',' ','X'},
    {'X','X','X','X','X',' ','X','X','X'}};  // Zeile 6
  
  static void zeichne(char [][] lab){
    System.out.println();
    for (int zeile=0; zeile<zeilenAnzahl ;zeile++ ) {
      for (int spalte=0; spalte<spaltenAnzahl ;spalte++ ) {
        System.out.print(lab[zeile][spalte]);
      } // end of for spalte
      System.out.println();
    } //end of for zeile; 
    
  }    
  
  public static void main(String[] args) {
    zeichne(laby);
  } // end of main
  
} // end of class Labyrinth
