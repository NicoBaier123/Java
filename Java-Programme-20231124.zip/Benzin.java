/**
  *
  * Description
  * Berechnung des Verbrauchs pro 100 km
  * z.B Distanz 320 km Verbrauch 20 Liter 
  * ergibt 6.25 L/100km oder 16 km pro Liter 
  * @version 1.0 from 02.12.2012
  * @author Bernhard Six
  */

import java.util.Scanner;
public class Benzin {
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);  
    double distance, consumption, consum100, dist1;
    System.out.println("Berechnung des Benzin-Verbrauchs\n");
    System.out.print("Gefahrene Strecke in km: ");
    distance = scanner.nextDouble();
    System.out.print("Ben�tigtes Benzin in Liter: ");
    consumption = scanner.nextDouble();
    consum100=consumption/distance*100;
    dist1=distance/consumption;
    System.out.printf("Der Verbrauch liegt bei %.2f Liter pro 100 km.\n",consum100);
    System.out.printf("Sie k�nnen eine Strecke von %.2f km pro Liter zur�cklegen.\n",dist1);
    scanner.close();
  } // end of main
  
} // end of class Benzin
